#Bài 1:
#a. Ngôn ngữ lập trình Python được tạo ra bởi ai và vào thời gian nào?
#Python là một ngôn ngữ lập trình cấp cao, được sửa dụng rộng rãi với nhiều mục đích. Ban đầu nó được thiết kế bởi Guido van Rossum - một lập trình viên người Hà Lan vào năm 1991 và sau đó được phát triển bởi Python Software Foundation.

#b. Vì sao ngôn ngữ lập trình Python lại được đặt tên như vậy?
#Khi bắt đầu triển khai Python, Guido van Rossum cũng đang đọc kịch bản của “Monty Python's Flying Circus", một series phim hài kịch của BBC từ những năm 1970. Van Rossum nghĩ rằng ông ấy cần một cái tên ngắn gọn, độc đáo và hơi bí ẩn, vì vậy ông ấy quyết định đặt tên ngôn ngữ này là Python.

#c. Tính tới ngày 13/07/2022, phiên bản Python mới nhất được phát hành là phiên bản nào?
#Tính tới ngày 13/07/2022, phiên bản Python mới nhất được phát hành là: Python 3.10.5
#Release Date: June 6, 2022