#Bài tập 3. pip
#a) Công cụ pip được sử dụng vào mục đích gì?
# pip (Pip Installs Python) is used to install, uninstall, update etc. any package within PyPI which is the Python Package Index.

#b) Giải thích ý nghĩa của câu lệnh pip freeze.
#pip freeze shows packages you installed via pip command in a requirements format.
# Example: pip freeze > requirements.txt
#The freeze command tells pip to write the names of all the packages currently installed in the project into the file requirements.txt.

#c) Chỉ ra một công cụ khác có chức năng tương tự pip.
#Alternatives to pip: Conda, Pipenv, Poetry.